setwd("C:\\Users\\IT24100101\\Desktop\\IT24100101")
getwd()
